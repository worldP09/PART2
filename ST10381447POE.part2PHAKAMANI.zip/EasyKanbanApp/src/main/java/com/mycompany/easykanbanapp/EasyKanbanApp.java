
package com.mycompany.easykanbanapp;
import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.List;

public class EasyKanbanApp {
    
    private static final String WELCOME_MESSAGE = "Welcome to EasyKanban";

    private static List<Task> tasks = new ArrayList<>();
    private static int taskCount = 0;

    public static void main(String[] args) {
        
        
        JOptionPane.showMessageDialog(null, WELCOME_MESSAGE);

        boolean loggedIn = false;  
        while (!loggedIn) {
            loggedIn = performLogin();
        }

        int choice = 0;
        while (choice != 3) {
            choice = displayMenu();
            switch (choice) {
                case 1:
                    addTask();
                    printTaskDetails();
                    break;
                case 2:
                    // Show report
                    displayReport();
                    break;
                case 3:
                    JOptionPane.showMessageDialog(null, "Exiting EasyKanban");
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid choice! Please try again.");
                    break;
            }
        }
    }

    public static boolean performLogin() {
          LOGIN check2 = new LOGIN();
                check2.name();
                check2.lastName();
                check2.user();
                check2.pass();
                check2.registerUser("","");
                check2.loginUser("","");
                check2.returnLoginStatus();
        return true;
    }

    public static int displayMenu() {
        String menu = "Please choose an option:\n" +
                      "1) Add tasks\n" +
                      "2) Show report\n" +
                      "3) Quit";
        String choice = JOptionPane.showInputDialog(null, menu);
        return Integer.parseInt(choice);
    }

  static String  addTask() {
    int numberOfTasks = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter the number of tasks:"));
    for (int i = 0; i < numberOfTasks; i++) {
        Task task = new Task();
        // Set task number using taskCount
        task.setTaskNumber(taskCount); 
        // Increment taskCount
        taskCount++; 

        String taskName = JOptionPane.showInputDialog(null, "Enter the task name:");
        task.setTaskName(taskName);

        String taskDescription = JOptionPane.showInputDialog(null, "Enter the task description:");
        boolean validDescription = task.checkTaskDescription(taskDescription);
        while (!validDescription) {
            taskDescription = JOptionPane.showInputDialog(null, "Please enter a task description of less than 50 characters:");
            validDescription = task.checkTaskDescription(taskDescription);
        }
        task.setTaskDescription(taskDescription);

        String firstName = JOptionPane.showInputDialog(null, "Enter the developer's first name:");
        String lastName = JOptionPane.showInputDialog(null, "Enter the developer's last name:");
        task.setDeveloperDetails(firstName, lastName);

        int taskDuration = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter the task duration (in hours):"));
        task.setTaskDuration(taskDuration);

        // Task Status Menu
        String[] statusOptions = {"To Do", "Done", "Doing"};
        int statusChoice = JOptionPane.showOptionDialog(null, "Select the task status:", "Task Status", JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, statusOptions, statusOptions[0]);
        String taskStatus = statusOptions[statusChoice];
        task.setTaskStatus(taskStatus);

        task.generateTaskID();

        tasks.add(task);

        JOptionPane.showMessageDialog(null, "Task successfully captured");
    }
        return "true";
}
    public static void printTaskDetails() {
        StringBuilder report = new StringBuilder("Task Report:\n\n");
        int totalHours = 0;

        for (Task task : tasks) {
            report.append("Task Status: ").append(task.getTaskStatus()).append("\n");
            report.append("Developer Details: ").append(task.getDeveloperDetails()).append("\n");
            report.append("Task Number: ").append(task.getTaskNumber()).append("\n");
            report.append("Task Name: ").append(task.getTaskName()).append("\n");
            report.append("Task Description: ").append(task.getTaskDescription()).append("\n");
            report.append("Task ID: ").append(task.getTaskID()).append("\n");
            report.append("Task Duration: ").append(task.getTaskDuration()).append(" hours\n\n");
            
            totalHours += task.getTaskDuration();
        }

        report.append("Total Hours: ").append(totalHours);

        JOptionPane.showMessageDialog(null, report.toString());
        
    }
    public static void displayReport() {
    JOptionPane.showMessageDialog(null, "Coming Soon");
}
}