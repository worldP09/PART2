
package com.mycompany.easykanbanapp;

 public class Task {
        
        private String taskName;
        private int taskNumber;
        private String taskDescription;
        private String developerFirstName;
        private String developerLastName;
        private int taskDuration;
        private String taskID;
        private String taskStatus;

        public void setTaskName(String taskName) {
            this.taskName = taskName;
        }

        public void setTaskDescription(String taskDescription) {
            this.taskDescription = taskDescription;
        }

        public boolean checkTaskDescription(String taskDescription) {
            return taskDescription.length() <= 50;
        }

        public void setDeveloperDetails(String firstName, String lastName) {
            this.developerFirstName = firstName;
            this.developerLastName = lastName;
        }

        public void setTaskDuration(int taskDuration) {
            this.taskDuration = taskDuration;
        }
        
        public void setTaskNumber(int taskNumber) {
            this.taskNumber = taskNumber;
        }

        public void generateTaskID() {
            String taskNameAbbreviation = taskName.substring(0, 2).toUpperCase();
            String developerNameAbbreviation = developerLastName.substring(developerLastName.length() - 3).toUpperCase();
            this.taskID = taskNameAbbreviation + ":" + taskNumber + ":" + developerNameAbbreviation;
        }

        public void setTaskStatus(String taskStatus) {
            this.taskStatus = taskStatus;
        }

        public String getTaskStatus() {
            return taskStatus;
        }

        public String getDeveloperDetails() {
            return developerFirstName + " " + developerLastName;
        }

        public int getTaskNumber() {
            return taskNumber;
        }

        public String getTaskName() {
            return taskName;
        }

        public String getTaskDescription() {
            return taskDescription;
        }

        public String getTaskID() {
            return taskID;
        }

        public int getTaskDuration() {
            return taskDuration;
        }
    }

    

